

It is a maven build, I have the tomcat plug-in in the pow so it can be run with 

Apache Maven 2.2.1

mvn tomcat:run

I have also included a built war file "TestTest-0.0.1-SNAPSHOT.war"
that could be able to be dropped into a /webapps folder of any running tomcat7.

once running the website will be availible at

http://localhost:8080/TestTest



