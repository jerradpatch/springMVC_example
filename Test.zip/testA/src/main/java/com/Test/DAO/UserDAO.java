package com.Test.DAO;

import java.util.List;

import com.Test.Model.UserModel;

public interface UserDAO {
	
	public List<UserModel> getAllUserData();
}
